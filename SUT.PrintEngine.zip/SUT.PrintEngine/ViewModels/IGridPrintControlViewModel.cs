namespace SUT.PrintEngine.ViewModels
{
    public interface IGridPrintControlViewModel:IItemsPrintControlViewModel
    {
        
    }
}