﻿
namespace SUT.PrintEngine.ViewModels
{
    public interface IViewModel
    {
    }
}
