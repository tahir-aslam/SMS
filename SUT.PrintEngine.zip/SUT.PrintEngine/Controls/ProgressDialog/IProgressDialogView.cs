﻿using SUT.PrintEngine.Controls.WaitScreen;

namespace SUT.PrintEngine.Controls.ProgressDialog
{
    public interface IProgressDialogView : IWaitScreenView
    {
    }
}
